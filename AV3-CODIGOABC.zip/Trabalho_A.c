#include <stdio.h>
#include <string.h>

#define MAX 100

typedef struct {
    int id;
    char titulo[50];
    char artista[50];
    int minutos;
    int segundos;
    char genero[30];
} Musica;

Musica playlist[MAX];
int totalMusicas = 0;

int idExistente(int id) {
    for (int i = 0; i < totalMusicas; i++) {
        if (playlist[i].id == id) return 1;
    }
    return 0;
}

void ordenarPlaylist() {
    Musica temp;
    for (int i = 0; i < totalMusicas - 1; i++) {
        for (int j = i + 1; j < totalMusicas; j++) {
            if (strcmp(playlist[i].titulo, playlist[j].titulo) > 0) {
                temp = playlist[i];
                playlist[i] = playlist[j];
                playlist[j] = temp;
            }
        }
    }
}

void cadastrarMusica() {
    if (totalMusicas >= MAX) {
        printf("Playlist cheia!\n");
        return;
    }

    Musica nova;

    printf("\n=== CADASTRAR MÚSICA ===\n");

    printf("Digite o ID: ");
    scanf("%d", &nova.id);

    if (idExistente(nova.id)) {
        printf("ID já existe!\n");
        return;
    }

    getchar();

    printf("Título: ");
    fgets(nova.titulo, 50, stdin);
    nova.titulo[strcspn(nova.titulo, "\n")] = 0;

    printf("Artista: ");
    fgets(nova.artista, 50, stdin);
    nova.artista[strcspn(nova.artista, "\n")] = 0;

    printf("Minutos: ");
    scanf("%d", &nova.minutos);

    printf("Segundos: ");
    scanf("%d", &nova.segundos);

    printf("Gênero: ");
    getchar();
    fgets(nova.genero, 30, stdin);
    nova.genero[strcspn(nova.genero, "\n")] = 0;

    playlist[totalMusicas++] = nova;

    printf("Música cadastrada!\n");
}

void buscarPorId() {
    int id;

    printf("\n=== BUSCAR ===\n");
    printf("ID: ");
    scanf("%d", &id);

    for (int i = 0; i < totalMusicas; i++) {
        if (playlist[i].id == id) {

            printf("\nMúsica encontrada:\n");
            printf("ID: %d\n", playlist[i].id);
            printf("Título: %s\n", playlist[i].titulo);
            printf("Artista: %s\n", playlist[i].artista);
            printf("Duração: %d:%02d\n", playlist[i].minutos, playlist[i].segundos);
            printf("Gênero: %s\n", playlist[i].genero);

            return;
        }
    }

    printf("Não encontrada!\n");
}

void editarMusica() {
    int id;

    printf("\n=== EDITAR ===\n");
    printf("ID: ");
    scanf("%d", &id);

    for (int i = 0; i < totalMusicas; i++) {
        if (playlist[i].id == id) {

            int opcao;

            printf("\n1 - Título\n2 - Artista\n3 - Minutos\n4 - Segundos\n5 - Gênero\n");
            printf("Opção: ");
            scanf("%d", &opcao);

            getchar();

            switch (opcao) {
                case 1:
                    fgets(playlist[i].titulo, 50, stdin);
                    playlist[i].titulo[strcspn(playlist[i].titulo, "\n")] = 0;
                    break;

                case 2:
                    fgets(playlist[i].artista, 50, stdin);
                    playlist[i].artista[strcspn(playlist[i].artista, "\n")] = 0;
                    break;

                case 3:
                    scanf("%d", &playlist[i].minutos);
                    break;

                case 4:
                    scanf("%d", &playlist[i].segundos);
                    break;

                case 5:
                    getchar();
                    fgets(playlist[i].genero, 30, stdin);
                    playlist[i].genero[strcspn(playlist[i].genero, "\n")] = 0;
                    break;
            }

            return;
        }
    }

    printf("Não encontrada!\n");
}

void excluirMusica() {
    int id;

    printf("\n=== EXCLUIR ===\n");
    scanf("%d", &id);

    for (int i = 0; i < totalMusicas; i++) {
        if (playlist[i].id == id) {

            for (int j = i; j < totalMusicas - 1; j++) {
                playlist[j] = playlist[j + 1];
            }

            totalMusicas--;
            printf("Excluída!\n");
            return;
        }
    }

    printf("Não encontrada!\n");
}

void listarPlaylist() {
    if (totalMusicas == 0) {
        printf("Playlist vazia!\n");
        return;
    }

    ordenarPlaylist();

    printf("\n=== PLAYLIST ORDENADA ===\n");

    for (int i = 0; i < totalMusicas; i++) {
        printf("\n%d. %s\n", i + 1, playlist[i].titulo);
        printf("ID: %d\n", playlist[i].id);
        printf("Artista: %s\n", playlist[i].artista);
        printf("Duração: %d:%02d\n", playlist[i].minutos, playlist[i].segundos);
        printf("Gênero: %s\n", playlist[i].genero);
    }
}

int main() {
    int opcao;

    while (1) {
        printf("\n=== MENU ===\n");
        printf("1 - Cadastrar\n");
        printf("2 - Buscar\n");
        printf("3 - Editar\n");
        printf("4 - Excluir\n");
        printf("5 - Listar\n");
        printf("0 - Sair\n");
        printf("Opção: ");
        scanf("%d", &opcao);

        switch (opcao) {
            case 1: cadastrarMusica(); break;
            case 2: buscarPorId(); break;
            case 3: editarMusica(); break;
            case 4: excluirMusica(); break;
            case 5: listarPlaylist(); break;
            case 0: return 0;
        }
    }
}
