#include <stdio.h>
#include <stdlib.h>

typedef struct Cliente
{
    int senha;
    char nome[50];
    int idade;

    struct Cliente *prox;

} Cliente;

typedef struct
{
    Cliente *inicio;
    Cliente *fim;
} Fila;

void inicializar(Fila *f)
{
    f->inicio = NULL;
    f->fim = NULL;
}

int filaVazia(Fila *f)
{
    return (f->inicio == NULL);
}

void enfileirar(Fila *f)
{
    Cliente *novo;

    novo = (Cliente *) malloc(sizeof(Cliente));

    printf("Senha: ");
    scanf("%d", &novo->senha);

    printf("Nome: ");
    scanf(" %[^\n]", novo->nome);

    printf("Idade: ");
    scanf("%d", &novo->idade);

    novo->prox = NULL;

    if(filaVazia(f))
    {
        f->inicio = novo;
        f->fim = novo;
    }
    else
    {
        f->fim->prox = novo;
        f->fim = novo;
    }

    printf("Cliente adicionado!\n");
}

void atender(Fila *f)
{
    Cliente *aux;

    if(filaVazia(f))
    {
        printf("Fila vazia!\n");
        return;
    }

    aux = f->inicio;

    printf("\nCliente atendido:\n");
    printf("Senha: %d\n", aux->senha);
    printf("Nome: %s\n", aux->nome);
    printf("Idade: %d\n", aux->idade);

    f->inicio = aux->prox;

    if(f->inicio == NULL)
    {
        f->fim = NULL;
    }

    free(aux);
}

void mostrarFila(Fila *f)
{
    Cliente *aux;

    if(filaVazia(f))
    {
        printf("Fila vazia!\n");
        return;
    }

    aux = f->inicio;

    printf("\n=== FILA ===\n");

    while(aux != NULL)
    {
        printf("\nSenha: %d", aux->senha);
        printf("\nNome: %s", aux->nome);
        printf("\nIdade: %d\n", aux->idade);

        aux = aux->prox;
    }
}

void proximoCliente(Fila *f)
{
    if(filaVazia(f))
    {
        printf("Fila vazia!\n");
        return;
    }

    printf("\nProximo cliente:\n");
    printf("Nome: %s\n", f->inicio->nome);
}

void quantidadeClientes(Fila *f)
{
    Cliente *aux;
    int cont = 0;

    aux = f->inicio;

    while(aux != NULL)
    {
        cont++;
        aux = aux->prox;
    }

    printf("Quantidade de clientes: %d\n", cont);
}

int main()
{
    Fila fila;
    int opcao;

    inicializar(&fila);

    do
    {
        printf("\n===== BANCO =====\n");
        printf("1 - Adicionar cliente\n");
        printf("2 - Atender cliente\n");
        printf("3 - Mostrar fila\n");
        printf("4 - Proximo cliente\n");
        printf("5 - Quantidade de clientes\n");
        printf("6 - Sair\n");
        printf("Opcao: ");
        scanf("%d", &opcao);

        switch(opcao)
        {
            case 1:
                enfileirar(&fila);
                break;

            case 2:
                atender(&fila);
                break;

            case 3:
                mostrarFila(&fila);
                break;

            case 4:
                proximoCliente(&fila);
                break;

            case 5:
                quantidadeClientes(&fila);
                break;

            case 6:
                printf("Programa encerrado.\n");
                break;

            default:
                printf("Opcao invalida!\n");
        }

    } while(opcao != 6);

    return 0;
}