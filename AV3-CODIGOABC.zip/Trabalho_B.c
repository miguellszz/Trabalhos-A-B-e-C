#include <stdio.h>
#include <string.h>
#include <stdlib.h>

typedef struct No {
    int protocolo;
    char local[50];
    char tipo[30];
    char horario[20];
    struct No *proxima;
} No;

No *topo = NULL;

int totalRegistradas = 0;
int totalAtendidas   = 0;

int pilhaVazia() {
    return topo == NULL;
}

int buscarProtocolo(int protocolo) {
    No *atual = topo;

    while (atual != NULL) {
        if (atual->protocolo == protocolo) {
            return 1;
        }
        atual = atual->proxima;
    }
    return 0;
}

void limparBuffer() {
    int c;
    while ((c = getchar()) != '\n' && c != EOF);
}

void exibirRegistro(No *registro) {
    printf("  Protocolo: %d\n", registro->protocolo);
    printf("  Local:     %s\n", registro->local);
    printf("  Tipo:      %s\n", registro->tipo);
    printf("  Horario:   %s\n", registro->horario);
}

void push() {
    No *novo;

    printf("\n--- REGISTRAR CHAMADA ---\n");

    novo = (No *)malloc(sizeof(No));
    if (novo == NULL) {
        printf("ERRO: Falha ao alocar memoria para novo registro.\n");
        return;
    }

    printf("Protocolo: ");
    if (scanf("%d", &novo->protocolo) != 1) {
        printf("ERRO: Protocolo invalido. Digite apenas numeros.\n");
        limparBuffer();
        free(novo);
        return;
    }
    limparBuffer();

    if (novo->protocolo <= 0) {
        printf("ERRO: Protocolo deve ser um numero positivo.\n");
        free(novo);
        return;
    }

    if (buscarProtocolo(novo->protocolo)) {
        printf("ERRO: Protocolo %d ja existe na pilha!\n", novo->protocolo);
        free(novo);
        return;
    }

    printf("Local: ");
    fgets(novo->local, sizeof(novo->local), stdin);
    novo->local[strcspn(novo->local, "\n")] = '\0';

    if (strlen(novo->local) == 0) {
        printf("ERRO: Local e obrigatorio.\n");
        free(novo);
        return;
    }

    printf("Tipo (ex: Incendio, Acidente, Medica): ");
    fgets(novo->tipo, sizeof(novo->tipo), stdin);
    novo->tipo[strcspn(novo->tipo, "\n")] = '\0';

    if (strlen(novo->tipo) == 0) {
        printf("ERRO: Tipo e obrigatorio.\n");
        free(novo);
        return;
    }

    printf("Horario (ex: 14:35): ");
    fgets(novo->horario, sizeof(novo->horario), stdin);
    novo->horario[strcspn(novo->horario, "\n")] = '\0';

    if (strlen(novo->horario) == 0) {
        printf("ERRO: Horario e obrigatorio.\n");
        free(novo);
        return;
    }

    novo->proxima = topo;
    topo = novo;
    totalRegistradas++;

    printf("\nChamada registrada com sucesso.\n");
}

void pop() {
    No *temp;

    printf("\n--- ATENDER CHAMADA ---\n");

    if (pilhaVazia()) {
        printf("ERRO: Pilha vazia! Nenhuma chamada para atender.\n");
        return;
    }

    printf("\nAtendendo chamada:\n\n");
    exibirRegistro(topo);

    temp = topo;
    topo = topo->proxima;
    free(temp);
    totalAtendidas++;

    printf("\nChamada atendida e removida da pilha.\n");
}

void peek() {
    printf("\n--- CONSULTAR ULTIMA CHAMADA ---\n");

    if (pilhaVazia()) {
        printf("ERRO: Pilha vazia! Nenhuma chamada registrada.\n");
        return;
    }

    printf("\nUltima chamada registrada (topo da pilha):\n\n");
    exibirRegistro(topo);
}

void listar() {
    No *atual;
    int count = 1;

    printf("\n--- LISTA DE CHAMADAS ---\n");

    if (pilhaVazia()) {
        printf("Pilha vazia! Nenhuma chamada registrada.\n");
        return;
    }

    printf("\n[TOPO]\n");
    printf("----------------------------------------\n");

    atual = topo;
    while (atual != NULL) {
        printf("Posicao %d:\n", count);
        exibirRegistro(atual);
        printf("----------------------------------------\n");
        atual = atual->proxima;
        count++;
    }

    printf("[BASE]\n");
}

void salvarCSV() {
    FILE *arquivo;
    No *atual;
    int count = 0;

    printf("\n--- SALVAR CSV ---\n");

    if (pilhaVazia()) {
        printf("AVISO: Pilha vazia. Nenhuma chamada para salvar.\n");
        return;
    }

    arquivo = fopen("chamadas.csv", "w");
    if (arquivo == NULL) {
        printf("ERRO: Nao foi possivel criar o arquivo chamadas.csv\n");
        return;
    }

    fprintf(arquivo, "protocolo;local;tipo;horario\n");

    atual = topo;
    while (atual != NULL) {
        fprintf(arquivo, "%d;%s;%s;%s\n",
            atual->protocolo,
            atual->local,
            atual->tipo,
            atual->horario);
        atual = atual->proxima;
        count++;
    }

    fclose(arquivo);
    printf("Pilha salva com sucesso em chamadas.csv (%d registro(s)).\n", count);
}

void carregarCSV() {
    FILE *arquivo;
    char linha[150];
    char *token;
    No *novo, *temp;
    int count = 0;

    printf("\n--- CARREGAR CSV ---\n");

    arquivo = fopen("chamadas.csv", "r");
    if (arquivo == NULL) {
        printf("ERRO: Arquivo chamadas.csv nao encontrado.\n");
        return;
    }

    while (!pilhaVazia()) {
        temp = topo;
        topo = topo->proxima;
        free(temp);
    }

    fgets(linha, sizeof(linha), arquivo);

    while (fgets(linha, sizeof(linha), arquivo) != NULL) {
        linha[strcspn(linha, "\n")] = '\0';

        if (strlen(linha) == 0) continue;

        novo = (No *)malloc(sizeof(No));
        if (novo == NULL) {
            printf("AVISO: Falha ao alocar memoria. Carregamento interrompido.\n");
            break;
        }

        token = strtok(linha, ";");
        if (token == NULL) {
            free(novo);
            continue;
        }
        novo->protocolo = atoi(token);
        if (novo->protocolo <= 0) {
            free(novo);
            continue;
        }

        token = strtok(NULL, ";");
        if (token == NULL) {
            free(novo);
            continue;
        }
        strncpy(novo->local, token, sizeof(novo->local) - 1);
        novo->local[sizeof(novo->local) - 1] = '\0';

        token = strtok(NULL, ";");
        if (token == NULL) {
            free(novo);
            continue;
        }
        strncpy(novo->tipo, token, sizeof(novo->tipo) - 1);
        novo->tipo[sizeof(novo->tipo) - 1] = '\0';

        token = strtok(NULL, ";");
        if (token == NULL) {
            free(novo);
            continue;
        }
        strncpy(novo->horario, token, sizeof(novo->horario) - 1);
        novo->horario[sizeof(novo->horario) - 1] = '\0';

        novo->proxima = topo;
        topo = novo;
        count++;
    }

    fclose(arquivo);
    totalRegistradas += count;

    printf("%d chamada(s) carregada(s) com sucesso.\n", count);
}

void contar() {
    No *atual = topo;
    int count = 0;

    while (atual != NULL) {
        count++;
        atual = atual->proxima;
    }

    printf("\n--- QUANTIDADE DE CHAMADAS ---\n");
    printf("Total de chamadas na pilha: %d\n", count);
}

void relatorio() {
    No *atual = topo;
    int count = 0;

    while (atual != NULL) {
        count++;
        atual = atual->proxima;
    }

    printf("\n--- RELATORIO ---\n");
    printf("\nChamadas registradas:\n%d\n", totalRegistradas);
    printf("\nChamadas atendidas:\n%d\n", totalAtendidas);
    printf("\nChamadas atualmente na pilha:\n%d\n", count);
}

void limparPilha() {
    int opcao;
    No *temp;

    printf("\n--- LIMPAR PILHA ---\n");
    printf("\nDeseja realmente apagar todas as chamadas?\n");
    printf("1 - Sim\n");
    printf("2 - Nao\n");
    printf("Opcao: ");

    if (scanf("%d", &opcao) != 1) {
        limparBuffer();
        printf("Opcao invalida.\n");
        return;
    }
    limparBuffer();

    if (opcao == 1) {
        while (!pilhaVazia()) {
            temp = topo;
            topo = topo->proxima;
            free(temp);
        }
        printf("Pilha apagada com sucesso.\n");
    } else {
        printf("Operacao cancelada.\n");
    }
}

void exportarRelatorio() {
    FILE *arquivo;
    No *atual = topo;
    int count = 0;

    printf("\n--- EXPORTAR RELATORIO TXT ---\n");

    while (atual != NULL) {
        count++;
        atual = atual->proxima;
    }

    arquivo = fopen("relatorio.txt", "w");
    if (arquivo == NULL) {
        printf("ERRO: Nao foi possivel criar o arquivo relatorio.txt\n");
        return;
    }

    fprintf(arquivo, "===== RELATORIO DE CHAMADAS DE EMERGENCIA =====\n\n");
    fprintf(arquivo, "Chamadas registradas: %d\n", totalRegistradas);
    fprintf(arquivo, "Chamadas atendidas:   %d\n", totalAtendidas);
    fprintf(arquivo, "Chamadas na pilha:    %d\n", count);
    fprintf(arquivo, "\n===============================================\n");

    fclose(arquivo);
    printf("Relatorio exportado com sucesso em relatorio.txt\n");
}

void exibirMenu() {
    printf("\n===== PILHA DE CHAMADAS DE EMERGENCIA =====\n\n");
    printf("1 - Registrar Chamada (Push)\n");
    printf("2 - Atender Chamada (Pop)\n");
    printf("3 - Consultar Ultima Chamada (Peek)\n");
    printf("4 - Listar Chamadas\n");
    printf("5 - Salvar CSV\n");
    printf("6 - Carregar CSV\n");
    printf("7 - Quantidade de Chamadas\n");
    printf("8 - Relatorio\n");
    printf("9 - Limpar Pilha\n");
    printf("10 - Exportar Relatorio TXT\n");
    printf("0 - Sair\n\n");
    printf("Opcao: ");
}

int main() {
    int opcao;

    do {
        exibirMenu();

        if (scanf("%d", &opcao) != 1) {
            limparBuffer();
            printf("Opcao invalida! Digite um numero.\n");
            opcao = -1;
            continue;
        }
        limparBuffer();

        switch (opcao) {
            case 1:  push();              break;
            case 2:  pop();               break;
            case 3:  peek();              break;
            case 4:  listar();            break;
            case 5:  salvarCSV();         break;
            case 6:  carregarCSV();       break;
            case 7:  contar();            break;
            case 8:  relatorio();         break;
            case 9:  limparPilha();       break;
            case 10: exportarRelatorio(); break;
            case 0:  printf("\nSaindo do sistema. Ate logo!\n"); break;
            default: printf("\nOpcao invalida! Tente novamente.\n");
        }

    } while (opcao != 0);

    return 0;
}